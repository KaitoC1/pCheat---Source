#pragma once

unsigned int CRC32(void *pData, size_t iLen);